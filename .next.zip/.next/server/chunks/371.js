"use strict";
exports.id = 371;
exports.ids = [371];
exports.modules = {

/***/ 2371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Suits)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/Restaurant.png
/* harmony default export */ const Restaurant = ({"src":"/_next/static/media/Restaurant.38f4145c.png","height":81,"width":82,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYklEQVR42g3CPQqCUAAA4G+IN77JA7Q111BjEkF/w1uM8gJODaHgBdxFLyF4S/34IEpqjacAXF0Mko8cgjtGL7kaop+k9XdS2VgXSnsHZzfgqACVHWRKGdh6i3zNOgS9yWMBvf0Od83bxuQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Retail.png
/* harmony default export */ const Retail = ({"src":"/_next/static/media/Retail.0b5ddda8.png","height":75,"width":76,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYklEQVR42gXALQ6CUAAA4A/f2Gs2C8ViMRhNOj0DRa9gtDM32WxPIoGfaxA4ArdiBJyNegcEMrnBRalBRtRZJK3FH/YqOwSF2paTCrkNfgpu3ogiPo6UngBerjxMvpKkNruvIUgQn2rqC94AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Entertainment.png
/* harmony default export */ const Entertainment = ({"src":"/_next/static/media/Entertainment.33369bf0.png","height":90,"width":90,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaUlEQVR42g3DMQsBYQAA0Ldxyw0mzLpk06EYGAySkSS+QZJjsDAoKYvJ/en7ej3mSp2obeAOwdvISu5sKZBqGRv62jj6U9dX+Dm52Xmw99K1wFSuQaLnYibz8ZRAcBVZxykTBbYyTQe1CqgrER1J7qdyAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Brands.png
/* harmony default export */ const Brands = ({"src":"/_next/static/media/Brands.91daf383.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAATUlEQVR42jXJuwmAMBQAwENdw8YVnMPKyk8hpDIINiIYcHfhgeVxQIXFq+ihxm7XSi6xhww6BXKwwW0gSQQfMywywZUIm8MZG6wxGX9+U24L5+Whx5sAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/team.png
/* harmony default export */ const team = ({"src":"/_next/static/media/team.16611956.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWUlEQVR42h3HMQqCABhA4a+mgoKghoLOIYKIODq46KBeQnRw9Rh6XX/kLe/jgju4IcRLbTap48DPoogWXyC1a7Q2CfwNcmuU6UMYFaA0Ag+dKuo84QrePk4d4eYKxXWrXJIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Health.png
/* harmony default export */ const Health = ({"src":"/_next/static/media/Health.4d8e27d0.png","height":86,"width":86,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaElEQVR42i3HOwqCAAAA0EcUBBFERCS0BjU3BH2GDtHSZ2po6gAR6iSiuDt7DfFwDrq9BztPgbWHDVyF9iJ/J7EjEV62BuBH5a30lUncVFw05j7uzmoHmCpMzCTGMMJKLrXoZ4jAslMLndwPWx5RqgQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/NonProfit.png
/* harmony default export */ const NonProfit = ({"src":"/_next/static/media/NonProfit.fde7772a.png","height":70,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYElEQVR42g3FoQrCQAAA0Mc5m6iIQzAaROPAZFi0H8ip4VZkW94PLO3DN154lD6S9yJKNmQlrlqFsx8vHH11akSStcbBXlBoeBpED1C5sTNKskptC9xN/vIyKwJOehcEZn5ZC/vbSRPQAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/PublicFigure.png
/* harmony default export */ const PublicFigure = ({"src":"/_next/static/media/PublicFigure.74d8fe5a.png","height":70,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAXklEQVR42h3IuwqCUAAA0NO1qaHHHES/0VBTa1NLECL4AYLoVUREXPxuRc52CMgMZi8kcBOxMwjASYmrAgEOolYvtYez0V+nkukkfL23PuLnSe4B4LNyN6tEtcbksgBBJA3QDx/i5wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Suits.tsx











function Suits() {
    const suits = [
        {
            id: 1,
            img: Restaurant,
            desc: "Restaurant and Cafe Chain",
            delay: "100"
        },
        {
            id: 2,
            img: Retail,
            desc: "Retail Businesses",
            delay: "400"
        },
        {
            id: 3,
            img: Entertainment,
            desc: "Entertainment Businesses",
            delay: "700"
        },
        {
            id: 4,
            img: team,
            desc: "Community",
            delay: "1000"
        },
        {
            id: 5,
            img: Brands,
            desc: "Consumer Brands",
            delay: "1300"
        },
        {
            id: 6,
            img: Health,
            desc: "Health, Beauty and Fitness",
            delay: "1600"
        },
        {
            id: 7,
            img: NonProfit,
            desc: "Non-Profits",
            delay: "1900"
        },
        {
            id: 8,
            img: PublicFigure,
            desc: "Public Figures",
            delay: "2200"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "py-12 px-6 mx-auto max-w-screen-xl sm:px-8 md:px-12 lg:px-16 xl:px-24",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                "data-aos": "fade-up",
                "data-aos-offset": "350",
                children: /*#__PURE__*/ jsx_runtime.jsx("h2", {
                    className: "max-w-lg mx-auto text-4xl font-bold tracking-tight text-center text-black sm:text-5xl md:text-6xl leading-tighter font-rubik",
                    children: "Our Service is suitable for"
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "grid grid-cols-1 sm:grid-cols-4",
                children: suits.map(({ id , img , desc , delay  })=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col justify-center items-center mt-2 m-2 mb-5 pt-12 pb-8 rounded-xl cursor-pointer   transition transform duration-200 ease-out",
                        "data-aos": "zoom-out",
                        "data-aos-offset": "100",
                        "data-aos-delay": delay,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "relative h-16 w-16",
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                "data-aos-delay": delay,
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: img,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "text-center lg:p-5",
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                "data-aos-delay": delay,
                                children: /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                    className: "text-xl font-custom2 font-bold",
                                    children: desc
                                })
                            })
                        ]
                    }, id))
            })
        ]
    });
}
/* harmony default export */ const components_Suits = (Suits);


/***/ })

};
;