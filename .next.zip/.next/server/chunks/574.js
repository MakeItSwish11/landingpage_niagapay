"use strict";
exports.id = 574;
exports.ids = [574];
exports.modules = {

/***/ 3574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Built)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/Fast.png
/* harmony default export */ const Fast = ({"src":"/_next/static/media/Fast.8560e380.png","height":148,"width":147,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAVElEQVR42k3HMQ5DUAAA0Nf/hy5N26E1CrGyWCRGFoM4gVgMLuAGLm7kbQ8CRq1dAg+kGh8VIgG9p8XkD+Rm0dfmDbwMep0fAhGFVYYIcKjvLc1XT+QWBpj1A52uAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Own.png
/* harmony default export */ const Own = ({"src":"/_next/static/media/Own.21d3d3e1.png","height":122,"width":122,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAbElEQVR42h3GOw4BYRhA0VPSi2WQYB+a6Sg0RGYyibeYEaWVKCisQRR6u7CMz+TPLc5lr1KYNRXO1tQhGBglL+Rp3m7JklXQdnfVCrYs9X18Pbz05EyMPWWGfjJTjkEnBN2gYuNk4WBnrlb+Aa/vI2at6hlfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Customized.png
/* harmony default export */ const Customized = ({"src":"/_next/static/media/Customized.1d134402.png","height":139,"width":139,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYklEQVR42gXAIQ6CUAAA0Gdwk2nQotniDZxG3Sf5nTMxN5zBxEYhAYFG5gCMyzLY+kod9fbAU/D2UbnAzkNUKQQBll4yg8ZNCmQ6P6VcAmxc5UaTCCRatZOzvxULRAdwt54B4csOBueyaNEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Built.tsx






function Built() {
    const built = [
        {
            id: 1,
            img: Fast,
            title: "Instant Activation",
            desc: "Start accepting payments instantly with online registration and a few supporting documents.",
            delay: "100"
        },
        {
            id: 2,
            img: Own,
            title: "Dashboard",
            desc: "Manage your payment operations with real time data from the Niagapay dashboard.",
            delay: "100"
        },
        {
            id: 3,
            img: Customized,
            title: "100+ Payment Methods",
            desc: "Receive and send payments through all E-Wallets, Banks, VA, Credit / Debit Cards and More.",
            delay: "100"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "py-12 px-6 mx-auto max-w-screen-xl sm:px-8 md:px-12 lg:px-16 xl:px-24",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                "data-aos": "fade-up",
                "data-aos-offset": "350",
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime.jsx("h2", {
                    className: "max-w-lg text-4xl font-bold tracking-tight text-center text-black sm:text-5xl md:text-5xl leading-tighter font-rubik",
                    children: "Why Integrate with us"
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "flex flex-col items-center pt-12 sm:items-start sm:flex-row md:pt-18",
                children: built.map(({ id , img , title , desc , delay  })=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col items-center w-full max-w-sm pt-8 text-center sm:text-left sm:block sm:pt-0 md:w-1/3",
                        "data-aos": "zoom-out",
                        "data-aos-offset": "100",
                        "data-aos-delay": delay,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "relative h-16 w-16",
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: img,
                                    alt: "",
                                    width: 80,
                                    height: 80
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                        className: "pt-3 text-xl font-bold text-black sm:pt-6 font-rubik",
                                        children: title
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "pt-4 pr-8 text-sm leading-relaxed text-gray-700 md:pr-16",
                                        children: desc
                                    })
                                ]
                            })
                        ]
                    }, id))
            })
        ]
    });
}
/* harmony default export */ const components_Built = (Built);


/***/ })

};
;