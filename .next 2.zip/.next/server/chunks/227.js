"use strict";
exports.id = 227;
exports.ids = [227];
exports.modules = {

/***/ 7227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Built)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/Fast.png
/* harmony default export */ const Fast = ({"src":"/_next/static/media/Fast.8560e380.png","height":148,"width":147,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAVElEQVR42k3HMQ5DUAAA0Nf/hy5N26E1CrGyWCRGFoM4gVgMLuAGLm7kbQ8CRq1dAg+kGh8VIgG9p8XkD+Rm0dfmDbwMep0fAhGFVYYIcKjvLc1XT+QWBpj1A52uAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Own.png
/* harmony default export */ const Own = ({"src":"/_next/static/media/Own.21d3d3e1.png","height":122,"width":122,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAbElEQVR42h3GOw4BYRhA0VPSi2WQYB+a6Sg0RGYyibeYEaWVKCisQRR6u7CMz+TPLc5lr1KYNRXO1tQhGBglL+Rp3m7JklXQdnfVCrYs9X18Pbz05EyMPWWGfjJTjkEnBN2gYuNk4WBnrlb+Aa/vI2at6hlfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Customized.png
/* harmony default export */ const Customized = ({"src":"/_next/static/media/Customized.1d134402.png","height":139,"width":139,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYklEQVR42gXAIQ6CUAAA0Gdwk2nQotniDZxG3Sf5nTMxN5zBxEYhAYFG5gCMyzLY+kod9fbAU/D2UbnAzkNUKQQBll4yg8ZNCmQ6P6VcAmxc5UaTCCRatZOzvxULRAdwt54B4csOBueyaNEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Managed.png
/* harmony default export */ const Managed = ({"src":"/_next/static/media/Managed.c469f30e.png","height":113,"width":113,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZklEQVR42gXAKwrCYAAA4E9UDOodDFaLM4rJWxgFs0FMgsWmoEEY/FtZWdgjbMu724C1WpAorYCfAzh6w1KGqTEyMwq1rYuznVZOL3b38vTw13ByxcYeQQzMfQQ3XxETIwuVTipiAHJoFUTjBAewAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Built.tsx







function Built() {
    const built = [
        {
            id: 1,
            img: Fast,
            title: "Launch Fast",
            desc: "Having Android & iOS mobile apps in just a few weeks",
            delay: "400"
        },
        {
            id: 2,
            img: Own,
            title: "Your Own App",
            desc: "Mobile apps with your own name, brand & corporate identity",
            delay: "700"
        },
        {
            id: 3,
            img: Customized,
            title: "Customized",
            desc: "Design and build app that follow your business process",
            delay: "1000"
        },
        {
            id: 4,
            img: Managed,
            title: "Managed Service",
            desc: "Developed, run, and managed by professional team",
            delay: "1300"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "py-8",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                "data-aos": "fade-up",
                "data-aos-offset": "350",
                children: /*#__PURE__*/ jsx_runtime.jsx("h1", {
                    className: " text-center font-custom2 text-5xl mb-8",
                    children: "Why Integrate with us"
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "grid grid-cols-1 sm:grid-cols-4",
                children: built.map(({ id , img , title , desc , delay  })=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col bg-gray-100 justify-center items-center mt-2 m-2 mb-5 pt-12 pb-8 rounded-xl cursor-pointer hover:bg-gray-100 hover:scale-105 transition transform duration-200 ease-out",
                        "data-aos": "zoom-out",
                        "data-aos-offset": "100",
                        "data-aos-delay": delay,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "relative h-16 w-16",
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: img,
                                    alt: "",
                                    className: "object-contain"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-center lg:p-5 lg:pt-10",
                                "data-aos": "fade-left",
                                "data-off-set": "350",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                        className: "font-custom1 font-bold",
                                        children: title
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "text-base font-custom2",
                                        children: desc
                                    })
                                ]
                            })
                        ]
                    }, id))
            })
        ]
    });
}
/* harmony default export */ const components_Built = (Built);


/***/ })

};
;